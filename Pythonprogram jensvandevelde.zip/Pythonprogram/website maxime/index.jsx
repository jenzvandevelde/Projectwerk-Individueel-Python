import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div>
      <Container className="mt-4">
        <Row>
          <Col lg={2} className="Image">
            <img src="fotos/GML-estate.png" alt="Chocoladetaart" style={{ maxWidth: '150px', maxHeight: '150px' }} />
          </Col>
          <Col lg={8}>
            <Button href="Klanten.html">Klanten</Button>
            <Button href="Factuur.html">Factuur</Button>
            <Button href="Groepsfactuur.html">Groepsfactuur</Button>
            <Button href="Creditnota.html">Creditnota</Button>
          </Col>
        </Row>
      </Container>

      <Container className="mt-4">
        <Row>
          <Col lg={3}>
            <Button>Klanten toevoegen</Button>
            <p className="tekstuitleg">Nieuwe klanten toevoegen</p>
          </Col>
          <Col lg={3}>
            <Button>Factuur maken</Button>
            <p className="tekstuitleg">Nieuwe factuur aanmaken</p>
          </Col>
          <Col lg={3}>
            <Button>Groepsfactuur maken</Button>
            <p className="tekstuitleg">Nieuwe groepsfactuur aanmaken</p>
          </Col>
          <Col lg={3}>
            <Button>Creditnota maken</Button>
            <p className="tekstuitleg">nieuwe creditnota aanmaken</p>
          </Col>
        </Row>
        <Row>
          <Col lg={3}>
            <Button>Klanten opzoeken</Button>
            <p className="tekstuitleg">Bestaande klanten opzoeken in het systeem</p>
          </Col>
          <Col lg={3}>
            <Button>Klanten Beheren</Button>
            <p className="tekstuitleg">Gegevens aanpassen van bestaande klanten</p>
          </Col>
          <Col lg={3}>
            <Button>Nieuw project</Button>
            <p className="tekstuitleg">Maak nieuw project aan</p>
          </Col>
          <Col lg={3}>
            <Button>Beheer projecten</Button>
            <p className="tekstuitleg">Beheer appartementen en schijven</p>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default App;
