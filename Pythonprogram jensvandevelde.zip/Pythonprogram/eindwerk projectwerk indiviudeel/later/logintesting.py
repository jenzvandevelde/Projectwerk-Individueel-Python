import hashlib

# Gebruikersdatabase (dit is een voorbeeld, je kunt een database gebruiken)
gebruikers = {
    'gebruikersnaam': 'wachtwoord',
    'voorbeeldgebruiker': 'wachtwoord123',
}

def hash_wachtwoord(wachtwoord):
    # Gebruik een sterke hashfunctie om het wachtwoord te hashen
    return hashlib.sha256(wachtwoord.encode()).hexdigest()

def toon_gehasht_wachtwoord():
    gebruikersnaam = input("Gebruikersnaam: ")
    
    if gebruikersnaam in gebruikers:
        gehasht_wachtwoord = gebruikers[gebruikersnaam]
        print(f"Het gehashte wachtwoord voor gebruiker {gebruikersnaam} is: {gehasht_wachtwoord}")
    else:
        print(f"Gebruiker {gebruikersnaam} niet gevonden.")

def inloggen():
    gebruikersnaam = input("Gebruikersnaam: ")
    wachtwoord = input("Wachtwoord: ")
    
    if gebruikersnaam in gebruikers and hash_wachtwoord(wachtwoord) == gebruikers[gebruikersnaam]:
        print("Inloggen geslaagd!")
    else:
        print("Ongeldige gebruikersnaam of wachtwoord.")

def registreren():
    nieuwe_gebruikersnaam = input("Nieuwe gebruikersnaam: ")
    nieuw_wachtwoord = input("Nieuw wachtwoord: ")
    
    # Voeg nieuwe gebruiker toe aan de gebruikersdatabase
    gehasht_wachtwoord = hash_wachtwoord(nieuw_wachtwoord)
    gebruikers[nieuwe_gebruikersnaam] = gehasht_wachtwoord
    print(f"Registratie geslaagd! Het gehashte wachtwoord is: {gehasht_wachtwoord}")

while True:
    print("1. Inloggen")
    print("2. Registreren")
    print("3. Toon gehasht wachtwoord")
    print("4. Afsluiten")
    
    keuze = input("Kies een optie: ")
    
    if keuze == '1':
        inloggen()
    elif keuze == '2':
        registreren()
    elif keuze == '3':
        toon_gehasht_wachtwoord()
    elif keuze == '4':
        break
    else:
        print("Ongeldige keuze. Probeer opnieuw.")
