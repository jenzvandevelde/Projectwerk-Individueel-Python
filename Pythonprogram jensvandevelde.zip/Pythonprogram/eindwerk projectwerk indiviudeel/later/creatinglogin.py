import pyodbc
import database_config  # Importeer het configuratiebestand

# Verbind met de database
connection = pyodbc.connect(database_config.connection_string_azure_sql_edge)

# Maak een cursor-object om queries uit te voeren
cursor = connection.cursor()

# Maak een nieuwe tabel 'gebruikers' als deze nog niet bestaat
cursor.execute('''
    CREATE TABLE IF NOT EXISTS gebruikers (
        gebruikersnaam TEXT PRIMARY KEY,
        wachtwoord_hash TEXT
    )
''')
connection.commit()

# Sluit de verbinding met de database wanneer je klaar bent
connection.close()
