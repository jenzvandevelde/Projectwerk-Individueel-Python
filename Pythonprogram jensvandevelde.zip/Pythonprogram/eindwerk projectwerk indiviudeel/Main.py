import subprocess

# Execute Database.py
subprocess.run(["python", "Database.py"])

# Execute ReadingxslxKopers.py
subprocess.run(["python", "ReadingxslxKopers.py"])

# Execute ReadingxslxSchijven.py
subprocess.run(["python", "ReadingxslxSchijven.py"])
