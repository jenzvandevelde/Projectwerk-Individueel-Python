import pyodbc

# Verbindingsgegevens
server = '192.168.68.73'   # IP-adres van je Raspberry Pi
database = 'python'  # Naam van de database waarmee je wilt verbinden
username = 'SA'            # Gebruikersnaam SA
password = 'Mylo1621'      # Wachtwoord

# Verbinding maken met de database
try:
    connection_string = f"DRIVER=ODBC Driver 17 for SQL Server;SERVER={server};DATABASE={database};UID={username};PWD={password}"
    connection = pyodbc.connect(connection_string)
    cursor = connection.cursor()

    # Voer hier je SQL-query in
    query = "SELECT 'Verbinding is geslaagd' AS Resultaat"
    cursor.execute(query)

    # Haal de resultaten op
    result = cursor.fetchone()
    print(result.Resultaat)

except Exception as e:
    print(f"Fout bij verbinden met de database: {str(e)}")

finally:
    # Sluit de verbinding
    if connection:
        connection.close()
