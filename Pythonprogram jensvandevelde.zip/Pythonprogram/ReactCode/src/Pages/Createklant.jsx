import React from 'react'
import SideNavbar from '../KlantOpzoekenComponenten/SideNavbar'
import CreateNewKlant from '../KlantOpzoekenComponenten/Createklant'

const Createklant = () => {
  return (
    <div>
        <SideNavbar/>
        <CreateNewKlant/>
    </div>
  )
}

export default Createklant