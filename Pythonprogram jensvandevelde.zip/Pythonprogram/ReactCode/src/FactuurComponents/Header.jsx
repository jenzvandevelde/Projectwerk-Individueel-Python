import React from 'react';

const Header = () => {
  return (
    <>
      <div className="container mt-4">
        <div className="row">
          <div className="col-lg-11 main-content">
            <p>Facturen</p>
          </div>
        </div>
      </div>
    </>
  );
}

export default Header;
