import React from 'react'

const Knoppen = () => {
  return (
    <div>
        <div className="container buttons">
  <div className="row">
    <div className="col-md-6">
      <button className="btn FactuurMaken">Factuur Maken</button>
    </div>
    <div className="col-md-6">
      <button className="btn FactuurMaken">Naar Klant verzenden</button>
    </div>
  </div>
</div>
    </div>
  )
}

export default Knoppen