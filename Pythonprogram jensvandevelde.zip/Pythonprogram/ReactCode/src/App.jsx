import React from 'react'
import KlantOpzoeken from './Pages/KlantOpzoeken'
import Factuurgenereren from './Pages/Factuurgenereren'


const App = () => {
  return (
    <div className="App">
      <Factuurgenereren/>
    </div>
  )
}

export default App